import random
import flet as ft
import json


def main(page: ft.Page):
    page.title = "Коммерсант 2026: Квантовый Синдикат"
    page.theme_mode = "dark"
    page.horizontal_alignment = "center"
    page.vertical_alignment = "center"

    # --- ЛОГИКА СОХРАНЕНИЙ ---
    def save_game(data):
        try:
            page.client_storage.set("cyber_bank_save", json.dumps(data))
        except:
            pass

    def load_game():
        try:
            if page.client_storage.contains_key("cyber_bank_save"):
                raw_data = page.client_storage.get("cyber_bank_save")
                if raw_data:
                    return json.loads(raw_data)
        except:
            pass
        return {"balance": 1000, "crypto": 0, "reputation": 10, "day": 1}

    player_data = load_game()

    # --- ИНТЕРФЕЙС (СТРОГИЕ СТРОКОВЫЕ НАСТРОЙКИ) ---
    balance_text = ft.Text(value=f"Баланс: {player_data['balance']} $", size=20, color="green")
    crypto_text = ft.Text(value=f"Криптовалюта: {player_data['crypto']} СВ", size=18, color="orange")
    rep_text = ft.Text(value=f"Репутация: {player_data['reputation']}", size=18, color="blue")
    day_text = ft.Text(value=f"День: {player_data['day']}/30", size=16, weight="bold")
    log_text = ft.Text(value="Синдикат ждет вашего хода.", size=14, italic=True)

    def update_ui():
        balance_text.value = f"Баланс: {player_data['balance']} $"
        crypto_text.value = f"Криптовалюта: {player_data['crypto']} СВ"
        rep_text.value = f"Репутация: {player_data['reputation']}"
        day_text.value = f"День: {player_data['day']}/30"
        page.update()

    # --- ИГРОВЫЕ ДЕЙСТВИЯ ---
    def work_click(e):
        if player_data['day'] >= 30:
            log_text.value = "Месяц окончен. Ваш путь в Синдикате завершен."
            update_ui()
            return

        earned = random.randint(150, 400)
        player_data['balance'] += earned
        player_data['day'] += 1
        log_text.value = f"Контракт выполнен: +{earned} $"
        save_game(player_data)
        update_ui()

    def buy_crypto_click(e):
        cost = random.randint(80, 120)
        if player_data['balance'] >= cost:
            player_data['balance'] -= cost
            player_data['crypto'] += 1
            log_text.value = f"Куплен 1 Квантовый Биткоин за {cost} $"
            save_game(player_data)
        else:
            log_text.value = f"Недостаточно средств. Нужно минимум {cost} $"
        update_ui()

    def reset_click(e):
        nonlocal player_data
        player_data = {"balance": 1000, "crypto": 0, "reputation": 10, "day": 1}
        save_game(player_data)
        log_text.value = "Прогресс успешно сброшен."
        update_ui()

    # --- КНОПКИ БЕЗ СТИЛЕЙ (ЧТОБЫ НЕ БЫЛО ОШИБОК АРГУМЕНТОВ) ---
    work_btn = ft.ElevatedButton(
        text="Работать (Пропустить день)",
        on_click=work_click,
        width=350,
        height=50
    )

    crypto_btn = ft.ElevatedButton(
        text="Купить Криптовалюту",
        on_click=buy_crypto_click,
        width=350,
        height=50
    )

    reset_btn = ft.TextButton(
        text="Начать заново",
        on_click=reset_click
    )

    # --- КОМПОНОВКА ---
    game_card = ft.Container(
        content=ft.Column(
            controls=[
                ft.Text("КОММЕРСАНТ 2026", size=28, weight="bold", color="cyan"),
                ft.Divider(),
                day_text,
                balance_text,
                crypto_text,
                rep_text,
                ft.Divider(),
                ft.Container(content=log_text, padding=10, bgcolor="#202020", border_radius=5, width=350),
                work_btn,
                crypto_btn,
                ft.Divider(),
                reset_btn
            ],
            horizontal_alignment="center",
            spacing=15
        ),
        padding=30,
        bgcolor="#151515",
        border_radius=15,
        width=420
    )

    page.add(game_card)


if __name__ == "__main__":
    ft.app(target=main)