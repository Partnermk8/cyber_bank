import random
import flet as ft
import json


def main(page: ft.Page):
    page.title = "Коммерсант 2026: Квантовый Синдикат"

    # Настройки темы для веб-интерфейса
    page.theme_mode = ft.ThemeMode.DARK
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.vertical_alignment = ft.MainAxisAlignment.CENTER

    # --- ЛОГИКА СОХРАНЕНИЯ И ЗАГРУЗКИ (Через Local Storage браузера) ---
    def save_game(data):
        try:
            # Превращаем словарь в строку JSON и сохраняем в песочницу браузера
            page.client_storage.set("cyber_bank_save", json.dumps(data))
        except Exception as e:
            print(f"Ошибка сохранения: {e}")

    def load_game():
        try:
            if page.client_storage.contains_key("cyber_bank_save"):
                raw_data = page.client_storage.get("cyber_bank_save")
                return json.loads(raw_data)
        except Exception as e:
            print(f"Ошибка загрузки: {e}")
        return None

    # --- ИНИЦИАЛИЗАЦИЯ ДАННЫХ ИГРОКА ---
    # Пытаемся загрузить старый сейв, если его нет — создаем новый
    player_data = load_game()

    if not player_data:
        player_data = {
            "balance": 1000,
            "crypto": 0,
            "reputation": 10,
            "day": 1
        }
        save_game(player_data)

    # --- ИНТЕРФЕЙС ИГРЫ ---
    # Текстовые элементы для вывода параметров
    balance_text = ft.Text(f"Баланс: {player_data['balance']} $", size=20, color=ft.colors.GREEN)
    crypto_text = ft.Text(f"Криптовалюта: {player_data['crypto']} СВ", size=18, color=ft.colors.ORANGE)
    rep_text = ft.Text(f"Репутация: {player_data['reputation']}", size=18, color=ft.colors.BLUE)
    day_text = ft.Text(f"День: {player_data['day']}/30", size=16, weight=ft.FontWeight.BOLD)
    log_text = ft.Text("Добро пожаловать в Квантовый Синдикат. Сделайте ваш первый ход.", size=14, italic=True)

    # Функция обновления интерфейса на экране
    def update_ui():
        balance_text.value = f"Баланс: {player_data['balance']} $"
        crypto_text.value = f"Криптовалюта: {player_data['crypto']} СВ"
        rep_text.value = f"Репутация: {player_data['reputation']}"
        day_text.value = f"День: {player_data['day']}/30"
        page.update()

    # --- ИГРОВЫЕ ДЕЙСТВИЯ ---
    def work_click(e):
        if player_data['day'] >= 30:
            log_text.value = "Игра окончена! Проверьте ваши финальные результаты."
            update_ui()
            return

        earned = random.randint(150, 400)
        player_data['balance'] += earned
        player_data['day'] += 1
        log_text.value = f"Вы выполнили контракт синдиката и заработали +{earned} $"

        save_game(player_data)  # Автосохранение
        update_ui()

    def buy_crypto_click(e):
        crypto_cost = random.randint(80, 120)
        if player_data['balance'] >= crypto_cost:
            player_data['balance'] -= crypto_cost
            player_data['crypto'] += 1
            log_text.value = f"Куплен 1 Квантовый Биткоин за {crypto_cost} $"
            save_game(player_data)
        else:
            log_text.value = f"Недостаточно средств! Нужно минимум {crypto_cost} $"
        update_ui()

    def reset_game_click(e):
        nonlocal player_data
        player_data = {"balance": 1000, "crypto": 0, "reputation": 10, "day": 1}
        save_game(player_data)
        log_text.value = "Прогресс успешно сброшен!"
        update_ui()

    # --- КНОПКИ ДЕЙСТВИЙ ---
    work_btn = ft.ElevatedButton("Работать на Синдикат (Пропустить день)", on_click=work_click, width=350, height=50)
    crypto_btn = ft.ElevatedButton("Купить Криптовалюту", on_click=buy_crypto_click, width=350, height=50,
                                   bgcolor=ft.colors.ORANGE_800, color=ft.colors.WHITE)
    reset_btn = ft.TextButton("Начать игру заново", on_click=reset_game_click, color=ft.colors.RED_400)

    # --- РАЗМЕЩЕНИЕ НА СТРАНИЦЕ ---
    # Ограничиваем контент красивой мобильной колонкой по центру браузера
    game_card = ft.Container(
        content=ft.Column(
            controls=[
                ft.Text("КОММЕРСАНТ 2026", size=28, weight=ft.FontWeight.BOLD, color=ft.colors.CYAN),
                ft.Divider(),
                day_text,
                balance_text,
                crypto_text,
                rep_text,
                ft.Divider(),
                ft.Container(content=log_text, padding=10, bgcolor=ft.colors.BLACK26, border_radius=5, width=350),
                ft.VerticalDivider(height=20),
                work_btn,
                crypto_btn,
                ft.Divider(),
                reset_btn
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=15
        ),
        padding=30,
        bgcolor=ft.colors.GREY_900,
        border_radius=15,
        border=ft.border.all(1, ft.colors.CYAN_700),
        width=400
    )

    page.add(game_card)
    update_ui()


# Запуск приложения
if __name__ == "__main__":
    ft.app(target=main)